﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
using System.Management.Instrumentation;
using System.Collections.Specialized;
using System.Threading;

namespace cpu_usage
{
    public partial class HiddenForm : Form
    {
        NotifyIcon CPUUsageIcon;
        Icon idleIcon;
        Icon normalIcon;
        Icon abovenormalIcon;
        Thread cpuUsageWorker;

        #region Form Stuff
        public HiddenForm()
        {
            InitializeComponent(); 
            
            // Load icons
            normalIcon = new Icon("orange-icon.ico");
            idleIcon = new Icon("green-icon.ico");
            abovenormalIcon = new Icon("red-icon.ico");

            //Create notify icons
            CPUUsageIcon = new NotifyIcon();
            CPUUsageIcon.Icon = normalIcon;
            CPUUsageIcon.Text = "CPU Usage"; { ManagementClass cpuDataClass = new ManagementClass("Win32_PerfFormattedData_Counters_ProcessorInformation"); }
            CPUUsageIcon.Visible = true;
            

            // Create all context menu items and add them to notification tray icon
            MenuItem progNameMenuItem = new MenuItem("CPU Usage v0.1 BETA by: Faizan Zafar and Zachary Covarrubias");
            MenuItem breakMenuItem = new MenuItem("-");
            MenuItem quitMenuItem = new MenuItem("Quit");
            ContextMenu contextMenu = new ContextMenu();
            contextMenu.MenuItems.Add(progNameMenuItem);
            contextMenu.MenuItems.Add(breakMenuItem);
            contextMenu.MenuItems.Add(quitMenuItem);
            CPUUsageIcon.ContextMenu = contextMenu;
            

            // Wire up quit button to close application
            quitMenuItem.Click += quitMenuItem_Click;
            progNameMenuItem.Click += progNameMenuItem_Click;    
           

            //
            //Hide the form
            //
            this.WindowState = FormWindowState.Minimized; 
            this.ShowInTaskbar = false;
            
            //Srart worker thread
            cpuUsageWorker = new Thread(new ThreadStart(CPUUageThread));
            cpuUsageWorker.Start();

        }

        void progNameMenuItem_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        void quitMenuItem_Click(object sender, EventArgs e)
        {
            cpuUsageWorker.Abort();
            CPUUsageIcon.Dispose();
            this.Close();
        }

        #endregion

        #region CPU Usage Activity Threads

        public void CPUUageThread()
        {
            ManagementClass cpuDataClass = new ManagementClass("Win32_PerfFormattedData_Counters_ProcessorInformation");
            try
            {
                
                //Main loop
                while (true)
                {
                    ManagementObjectCollection cpuDataClassCollection = cpuDataClass.GetInstances();
                    foreach( ManagementObject obj in cpuDataClassCollection)
                    {
                        // Only process the _Total instance and ignore all the indevidual instances
                        if (obj["Name"].ToString() == "_Total")
                        {
                            if (Convert.ToUInt64(obj["PercentProcessorTime"]) >= 60 )
                            {
                                // Show busy icon idleIcon
                                CPUUsageIcon.Icon = abovenormalIcon;
                            }
                            else if (Convert.ToUInt64(obj["PercentProcessorTime"]) >= 30)
                            {
                                // Show idle icon
                                CPUUsageIcon.Icon = normalIcon;
                            }
                            else
                            {
                                // Show idle icon
                                CPUUsageIcon.Icon = idleIcon;
                            }

                        }
                    }

                    // Sleep for 10th of millisecond 
                    Thread.Sleep(100);
                }
            }
            catch (ThreadAbortException tbe)
            {
               cpuDataClass.Dispose();
                // Thead was aborted
            }
        }

        private void OnMouseMove()
        {
            throw new NotImplementedException();
        }
        #endregion

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://zachcova.com/AboutMe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://everythinghacks.com/about");
        }
      
        
        //This is just beta testing 
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }
        private void HiddenForm_Resize(object sender, System.EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
                this.ShowInTaskbar = false;
        }

        private void HiddenForm_Load(object sender, EventArgs e)
        {

        }
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
         
    }     

}